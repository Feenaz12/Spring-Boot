package org.generation.dependencies_injection.service;

import org.generation.dependencies_injection.model.Student;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Primary
@Service
public class StudentServiceImpl implements StudentService {

    private final List<Student> students;

    public StudentServiceImpl() {
        this.students = new ArrayList<>();
        initializeTestData(); // You can add some initial test students in this method.
    }

    @Override
    public void add(Student student) {
        students.add(student);
    }

    @Override
    public void delete(Student student) {
        students.remove(student);
    }

    @Override
    public List<Student> all() {
        return students;
    }

    @Override
    public Student findById(String id) {
        for (Student student : students) {
            if (student.getIdStudent().equals(id)) {
                return student;
            }
        }
        return null; // Student not found
    }

    // Method to add some initial test students
    private void initializeTestData() {
        add(new Student("1", 0, "Mary", "Doe", 1));
        //add(new Student("2", 0, "Kelvin", "Smith", 2));
        // Add more test students as needed
    }
}
