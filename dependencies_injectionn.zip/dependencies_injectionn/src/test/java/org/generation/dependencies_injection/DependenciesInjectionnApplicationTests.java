package org.generation.dependencies_injection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependenciesInjectionnApplicationTests {

	@Test
	void contextLoads() {
	}

}
