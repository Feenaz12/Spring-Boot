package data.Service;

import data.Entity.Product;
import data.Entity.Sale;

import java.util.List;

public interface SaleService {
    List<Sale> getAllSales();
    Sale getSaleById(Long id);
    Sale createSale(Sale sale);
    Sale updateSale(Long id, Sale sale);
    void deleteSale(Long id);
    List<Product> getProductsForSale(Long saleId);
}
