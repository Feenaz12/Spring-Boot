package data.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import data.Entity.Product;
import data.Entity.Sale;
import data.Repository.SalesRepository;
import data.Service.SaleService;

import java.util.List;

@Service
public class SaleServiceImpl implements SaleService {
    private final SalesRepository saleRepository;

    @Autowired
    public SaleServiceImpl(SalesRepository saleRepository) {
        this.saleRepository = saleRepository;
    }

    @Override
    public List<Sale> getAllSales() {
        return (List<Sale>) saleRepository.findAll();
    }

    @Override
    public Sale getSaleById(Long id) {
        return saleRepository.findById(id).orElse(null);
    }

    @Override
    public Sale createSale(Sale sale) {
        return saleRepository.save(sale);
    }

    @Override
    public Sale updateSale(Long id, Sale sale) {
        Sale existingSale = saleRepository.findById(id).orElse(null);
        if (existingSale != null) {
            existingSale.setDescription(sale.getDescription());
            existingSale.setTotal(sale.getTotal());
            return saleRepository.save(existingSale);
        } else {
            return null;
        }
    }

    @Override
    public void deleteSale(Long id) {
        saleRepository.deleteById(id);
    }

	@Override
	public List<Product> getProductsForSale(Long saleId) {
		// TODO Auto-generated method stub
		return null;
	}
}
