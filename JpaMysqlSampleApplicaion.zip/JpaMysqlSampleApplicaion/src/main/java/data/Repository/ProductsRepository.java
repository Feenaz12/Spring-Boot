package data.Repository;

import data.Entity.Product;
import org.springframework.data.repository.CrudRepository;

public interface ProductsRepository extends CrudRepository<Product, Long> {
    // You can add custom query methods here if needed
}
