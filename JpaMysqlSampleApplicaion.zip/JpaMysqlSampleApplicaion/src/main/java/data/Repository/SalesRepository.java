package data.Repository;

import data.Entity.Sale;
import org.springframework.data.repository.CrudRepository;

public interface SalesRepository extends CrudRepository<Sale, Long> {
    // You can add custom query methods here if needed
}
