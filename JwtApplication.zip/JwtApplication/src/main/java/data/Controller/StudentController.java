package data.Controller;

import data.Controller.dto.EnrollmentRequest;
import data.model.Student;
import data.Service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students")
public class StudentController {

    private final StudentService studentService;

    @Autowired
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    // Existing endpoints...

    @PostMapping("/enroll")
    public void enrollStudentInCourse(@RequestBody EnrollmentRequest enrollmentRequest) {
        studentService.enrollStudentInCourse(enrollmentRequest.getStudentId(), enrollmentRequest.getCourseId());
    }
}
