package data.Controller;

import data.model.Course;
import data.Service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CourseController {

    private final CourseService courseService;

    @Autowired
    public CourseController(@Autowired CourseService courseService) {
        this.courseService = courseService;
    }

    @CrossOrigin("*")
    @GetMapping("/api/courses")
    public List<Course> all() {
        return courseService.all();
    }

    @PostMapping("/api/courses")
    public Course save(@RequestBody Course course) {
        return courseService.save(course);
    }

    @DeleteMapping("/api/courses/{courseId}")
    public void delete(@PathVariable String courseId) {
        courseService.delete(courseId);
    }

    @PostMapping("/api/courses/{courseId}/enroll/{studentId}")
    public void enrollStudent(@PathVariable String courseId, @PathVariable int studentId) {
        courseService.enrollStudent(courseId, studentId);
    }
}
