package data.Service;

import data.model.Course;

import java.util.List;

public interface CourseService {

    List<Course> all();

    Course save(Course course);

    void delete(String courseId);

    void enrollStudent(String courseId, int studentId);
}
