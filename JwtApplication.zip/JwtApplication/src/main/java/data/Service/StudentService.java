package data.Service;

import data.model.Student;

import java.util.List;

public interface StudentService {

    List<Student> getAllStudents();

    Student getStudentById(int id);

    Student saveStudent(Student student);

    void deleteStudent(int id);

    void enrollStudentInCourse(int studentId, String courseId);
}
