package data.Service;

import data.Repository.CourseRepository;
import data.Repository.StudentRepository;
import data.model.Course;
import data.model.Enrollment;
import data.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;
    private final StudentRepository studentRepository;

    @Autowired
    public CourseServiceImpl(CourseRepository courseRepository, StudentRepository studentRepository) {
        this.courseRepository = courseRepository;
        this.studentRepository = studentRepository;
    }

    @Override
    public List<Course> all() {
        return courseRepository.findAll();
    }

    @Override
    public Course save(Course course) {
        return courseRepository.save(course);
    }

    @Override
    public void delete(String courseId) {
        courseRepository.deleteById(courseId);
    }

    @Override
    public void enrollStudent(String courseId, int studentId) {
        Optional<Course> courseOptional = courseRepository.findById(courseId);
        Optional<Student> studentOptional = studentRepository.findById(studentId);

        if (courseOptional.isPresent() && studentOptional.isPresent()) {
            Course course = courseOptional.get();
            Student student = studentOptional.get();

            // Check if the student is not already enrolled in the course
            if (!isStudentEnrolledInCourse(student, course)) {
                // Create an enrollment and add it to both student and course
                Enrollment enrollment = new Enrollment(student, course);
                student.getEnrollments().add(enrollment);
                course.getEnrollments().add(enrollment);

                studentRepository.save(student);
                courseRepository.save(course);
            }
        }
    }



    // Helper method to check if a student is already enrolled in a course
    private boolean isStudentEnrolledInCourse(Student student, Course course) {
        return student.getEnrollments().stream()
                .anyMatch(enrollment -> enrollment.getCourse().equals(course));
    }
}
