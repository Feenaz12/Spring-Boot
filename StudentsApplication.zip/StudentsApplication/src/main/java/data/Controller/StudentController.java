package data.Controller;

import data.Entity.Student;
import data.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students")
public class StudentController {

    private final StudentService studentService;

    @Autowired
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping
    public Iterable<Student> all() {
        return studentService.all();
    }

    @GetMapping("/{id}")
    public Student findById(@PathVariable String id) {
        // Assuming your service can find a student by a String ID
        int studentId = Integer.parseInt(id);
        return studentService.get(studentId);
    }

    @PostMapping
    public void save(@RequestBody Student student) {
        studentService.save(student);
    }

    @PutMapping
    public void update(@RequestBody Student student) {
        // Assuming you have a method to update an existing student in your service
        studentService.save(student);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        // Assuming your service can delete a student by a String ID
        int studentId = Integer.parseInt(id);
        studentService.delete(studentId);
    }
    @GetMapping("/startsWith")
    public Iterable<Student> findByFirstNameStartsWith(@RequestParam String query) {
        return studentService.findByFirstNameStartsWith(query);
    }
    
    
}
