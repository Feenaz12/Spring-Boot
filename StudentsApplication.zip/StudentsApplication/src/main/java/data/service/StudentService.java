package data.service;

import data.Entity.Student;

public interface StudentService
{

    Iterable<Student> all();

    Student get( int studentId );

    void save( Student student );

    void delete( int studentId );
}