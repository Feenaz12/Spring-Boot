package data.service;

import data.Entity.Student;

import java.util.List;

public interface StudentService {

    Iterable<Student> all();

    Student get(int studentId);

    void save(Student student);

    void delete(int studentId);

    List<Student> findByFirstNameStartsWith(String query);
}
