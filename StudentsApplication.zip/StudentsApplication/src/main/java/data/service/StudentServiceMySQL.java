package data.service;

import data.Repository.StudentRepository;
import data.Entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StudentServiceMySQL implements StudentService {

    private final StudentRepository studentsRepository;

    public StudentServiceMySQL(@Autowired StudentRepository studentsRepository) {
        this.studentsRepository = studentsRepository;
    }

    @Override
    public Iterable<Student> all() {
        return studentsRepository.findAll();
    }

    @Override
    public Student get(int studentId) {
        return studentsRepository.findById(studentId);
    }

    @Override
    public void save(Student student) {
        studentsRepository.save(student);
    }

    @Override
    public void delete(int studentId) {
        studentsRepository.deleteById(studentId);
    }

    @Override
    public List<Student> findByFirstNameStartsWith(String query) {
        List<Student> filteredStudents = new ArrayList<>();
        for (Student student : studentsRepository.findAll()) {
            if (student.getName().startsWith(query)) {
                filteredStudents.add(student);
            }
        }
        return filteredStudents;
    }


}
