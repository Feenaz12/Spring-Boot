package data.Repository;

import data.Entity.Student;
import org.springframework.data.repository.CrudRepository;

public interface StudentRepository
    extends CrudRepository<Student, Integer>
{

    Student findById( int id );

}